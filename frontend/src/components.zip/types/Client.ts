export interface Client {
  id: number;
  nombre: string;
  email: string;
  telefono: string;
  objetivo: string;
}