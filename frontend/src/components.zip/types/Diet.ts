export interface Diet {
    id: number;
    nombre: string;
    descripcion: string;
    calorias: number;
    proteinas: number;
}