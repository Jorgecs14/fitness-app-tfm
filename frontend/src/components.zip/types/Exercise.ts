export interface Exercise {
  id: number;
  name: string;
  description: string;
  executionTime?: number;
}